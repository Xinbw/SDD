data.zip —— 论文用表格（2026-09-22 重建）

新方案 = 聚合上的分布式离散高斯 + 多消息洗牌（SDD_PHASE1_NOTES.md §1），
100 客户端、cohort 10000（模拟）、q=1、T=3、K 逐 ε 取值、vote + 硬标签 CE、阈值 0、3 seeds。
旧方案 = 本地 DP + 洗牌放大，1000 客户端、q=0.1、T=6、按标签 ε。

| 文件 | 状态 |
|---|---|
| acc_compare.xlsx | Sheet1：SSD / DP-FedCT / PATE 已换成新方案（CIFAR-10 α=0.1）；DP-FedDPA / PPFed 保留旧方案数据。新增 sheet MNIST_and_alpha1（另三个组合） |
| acc_compare_claude.xlsx | 同上，首列 eps-per-label 改为 rho_per_round（zCDP，新方案无按标签 ε） |
| non-iid.xlsx | α=0.1 / α=1.0 已换新方案；α=10 保留旧方案。inc 改为相对 round-1 本地模型。新增 sheet MNIST |
| comm.xlsx | 重建：T 扫描（σ ∝ √T）+ T=3 主线 run 的逐轮曲线 |
| hetero_model.xlsx | 未改（新方案没跑异构架构） |
| hetero_proxy_data.xlsx | 未改（新方案没跑 CIFAR-100 / EMNIST 代理） |

生成脚本：export_data_zip.py。数字与 SSD_RESULTS.md / SSD_COMPARISON.md 一致。
